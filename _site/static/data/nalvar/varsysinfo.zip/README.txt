{\rtf1\ansi\ansicpg1252\cocoartf949\cocoasubrtf540
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 Notes on the variable NAL system plots:\
- The variable lines are included at the beginning of each system file.\
- Tables listing the lines detected in each system and their equivalent widths are also included (Tables 3 & 4 in the paper).\
- In the plots, I marked the location of each absorption line even if it wasn't detected.  It will help to refer to the Tables while looking at each plot to see which lines are detected and which are variable.\
- Section 5 includes descriptions of what I saw in each system so I would ask that you also refer to them as you look at each system.  Your help in confirming or refuting my observations will help in deciding which systems have realistic variations.}